<?php 
/**
 * Plugin Name: dGate
 * Description: Departika Age Gate
 * Version: 1.0
 * Author: Jamison Wight
 */

 // Options Scripts
include 'php/options.php';

// Functions
include 'php/functions.php';

// Admin Scripts
include 'php/admin_scripts.php';

// Header & Footer Scripts 
include 'php/load_scripts.php';