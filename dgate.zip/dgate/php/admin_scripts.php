<?php
function load_dgate_admin_scripts($hook)
{
        // Load only on ?page=mypluginname
        if ($hook != 'toplevel_page_dgate') {
                return;
        }
        //  CSS
        wp_enqueue_style('dgate_admin_css', plugins_url('css/dgate.css', __FILE__));
        wp_enqueue_style('dgate_foundation_css', plugins_url('css/foundation-grid.css', __FILE__));

        // Ace Editor
        wp_enqueue_script('ace-js', 'https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.5/ace.js', array('jquery'), '1.0', true);

        // JS
        wp_enqueue_script('dgate-js', plugins_url('js/dgate.js', __FILE__), array('jquery'), '1.0');

        // Editor JS
        wp_enqueue_script('dgate-editor', plugins_url('js/editor.js', __FILE__), array('jquery'), '1.0', true);
        wp_localize_script( 'dgate-editor', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

        // Font Awesome 
        wp_enqueue_style('font-awesome-css', 'https://use.fontawesome.com/releases/v5.7.2/css/all.css');
}
add_action('admin_enqueue_scripts', 'load_dgate_admin_scripts');


function media_uploader_enqueue() {
    wp_enqueue_media();
    wp_register_script('media-uploader', plugins_url('js/media-uploader.js' , __FILE__ ), array('jquery'));
    wp_enqueue_script('media-uploader');
}
add_action('admin_enqueue_scripts', 'media_uploader_enqueue');