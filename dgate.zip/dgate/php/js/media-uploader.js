jQuery(document).ready(function($){
    var mediaUploaderBackground,
        mediaUploaderLogo;

    // Background
    $('#dgate_background_upload').on('click', function(e) {
        e.preventDefault();
        if(mediaUploaderBackground) {
            mediaUploaderBackground.open();
            return;
        }

        mediaUploaderBackground = wp.media.frames.file_frame = wp.media({
            title: 'Choose Background',
            button: {
                text: 'Choose Background'
            }, 
            multiple: false
        });

        mediaUploaderBackground.on('select', function() {
            var attachment = mediaUploaderBackground.state().get('selection').first().toJSON();
            $('#dgate_background').val(attachment.url);
            $('#dgate_background_image_display').css('display', 'block');
            $('#dgate_background_image_display').attr('src', attachment.url);
        });
        mediaUploaderBackground.open();
    })



    // Logo
    $('#dgate_logo_upload').on('click', function(e) {
        e.preventDefault();
        if(mediaUploaderLogo) {
            mediaUploaderLogo.open();
            return;
        }

        mediaUploaderLogo = wp.media.frames.file_frame = wp.media({
            title: 'Choose Logo',
            button: {
                text: 'Choose Logo'
            }, 
            multiple: false
        });

        mediaUploaderLogo.on('select', function() {
            var attachment = mediaUploaderLogo.state().get('selection').first().toJSON();
            $('#dgate_logo').val(attachment.url);
            $('#dgate_logo_image_display').css('display', 'block');
            $('#dgate_logo_image_display').attr('src', attachment.url);
        });
        mediaUploaderLogo.open();
    })

});