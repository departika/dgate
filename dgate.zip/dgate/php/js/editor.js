document.addEventListener("DOMContentLoaded", function (event) {
    var jsEditorHTML = document.querySelector('#dgate_js_editor').innerHTML,
        jsEditor = ace.edit('dgate_js_editor'),
        cssEditor = ace.edit('dgate_css_editor'),
        dgateForm = document.querySelector('#editor-form'),
        modalContent = document.querySelector('#modal_content');

    // Trim the whitespace
    jsEditorHTML = jsEditorHTML.trim();

    // JS Settings
    jsEditor.setTheme("ace/theme/tomorrow_night_eighties");
    jsEditor.session.setMode("ace/mode/javascript");
    jsEditor.session.setValue(jsEditorHTML)

    // CSS Settings
    cssEditor.setTheme("ace/theme/tomorrow_night_eighties");
    cssEditor.session.setMode("ace/mode/css");
    
    dgateForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // Custom Template
        var jsTemplateData = {action: 'update_template', customTemplate: jsEditor.getValue()}
        jQuery.post(ajaxurl, jsTemplateData, function(response) {
        });

        // Custom CSS
        var cssTemplateData = {action: 'update_css', customCSS: cssEditor.getValue()}
        jQuery.post(ajaxurl, cssTemplateData, function(response) {

        });

        setTimeout(function() {
            window.location.reload(true);
        }, 1000)
    })
})