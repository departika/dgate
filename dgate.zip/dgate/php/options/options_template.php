<?php 
$template = get_option('dgate_custom_template');
$defaultTemplate = <<<EOT
var main_content = `
    <div id="modal_content" style="top: 0px; left: 0px;">
        <div id="modal_content_wrapper" class="content_wrapper">
            <div class="grid-container">
                <div class="grid-x grid-padding-x">
                    <div class="cell small-12 large-6 background" style="background-image: url({{background}})">
                    </div>
                    <div class="cell medium-8 medium-offset-2 large-6 large-offset-0 copy-content">
                        <div class="logo">
                            <img src="{{logo}}" alt="logo">
                        </div>
                        <h1 class="text-center padding-small heading-1">{{heading}}</h1>
                        <p>But first, are you of legal drinking age?</p>
                        <nav class="">
                            <ul>
                                <li><a href="#" class="av_btn" rel="yes" id="yes"><button class="btn-black">Yes</button></a>
                                </li>
                                <li><a href="#" class="av_btn" rel="no" id="no"><button class="btn-black">No</button></a>
                                </li>
                            </ul>
                        </nav>
                        <div class="agree"><input type="checkbox" id="agree" class="btn-default" required="">I agree to the
                        <a data-fancybox="" data-type="iframe" href="{{terms_of_service}}">Terms of Service</a> and <a data-fancybox="" data-type="iframe" href="{{privacy_policy}}">Privacy Policy</a></div>
                        <p class="small">You must be at least 21 years old to view this site. By clicking “yes” you affirm
                            that you are at least 21 years old.</p>
                        <p class="copyright small">© 2019 {{brand_name}}. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
        <div id="modal_regret_wrapper" class="content_wrapper" style="display:none;">
            <h2>{{regret_text}}</h2>
        </div>
    </div>
`
EOT;
?>


<section class="cell medium-8 medium-offset-2">
    <h1><span class="fa fa-file-code" aria-hidden="true"></span> Template</h1>
    <div class="grid-x grid-margin-x">
        <p class="cell">
            Edit template as needed. Use the custom tag fields with two enclosing brackets <span class="strong">({{field}})</span> related to the fields above using underscores for spaces. 
            For example, <span class="strong">'{{logo}}'</span> would be for the logo image. Also, you can insert content manually.</p>

        <!-- If Template is empty use a default template -->
        <div class="cell small-12" id="dgate_js_editor"><?php echo ((empty($template) || $template == '') ? $defaultTemplate : htmlspecialchars_decode(stripslashes($template))); ?></div>

    </div>
    <?php submit_button(); ?>
</section>