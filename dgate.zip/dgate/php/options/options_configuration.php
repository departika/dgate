<section class="cell medium-8 medium-offset-2">
        <h1><span class="fa fa-wrench" aria-hidden="true"></span> Configuration</h1>

        <div class="grid-x grid-margin-x">
            <h2 class="cell medium-6">Brand Name</h2>
            <div class="cell medium-6">
                <input type="text" name="dgate_brand_name" value="<?php echo esc_attr(get_option('dgate_brand_name')); ?>" />
            </div>
        </div>

        <div class="grid-x grid-margin-x dgate-background-upload">
            <h2 class="cell medium-6">Background</h2>
            <div class="cell medium-6 dgate-background-container">
                <input id="dgate_background" type="text" name="dgate_background" value="<?php echo esc_attr(get_option('dgate_background')); ?>" hidden/>
                <img id="dgate_background_image_display" src="<?php echo get_option('dgate_background'); ?>" alt="dgate background display image" />
                <input id="dgate_background_upload" type="button" class="button button-primary" value="Upload Background" />
            </div>
        </div>

        <div class="grid-x grid-margin-x dgate-logo-upload">
            <h2 class="cell medium-6">Logo</h2>
            <div class="cell medium-6 dgate-logo-container">
                <input id="dgate_logo" type="text" name="dgate_logo" value="<?php echo esc_attr(get_option('dgate_logo')); ?>" hidden />
                <img id="dgate_logo_image_display" src="<?php echo get_option('dgate_logo'); ?>" alt="dgate logo display image" />
                <input id="dgate_logo_upload" type="button" class="button button-primary" value="Upload Logo" />
            </div>
        </div>

        <div class="grid-x grid-margin-x">
            <h2 class="cell medium-6">Heading</h2>
            <div class="cell medium-6">
                <input id="dgate_heading" type="text" name="dgate_heading" value="<?php echo esc_attr(get_option('dgate_heading')); ?>" />
            </div>
        </div>

        <div class="grid-x grid-margin-x">
            <h2 class="cell medium-6">Terms of Service</h2>
            <div class="cell medium-6">
                <input id="dgate_terms_of_service" type="text" name="dgate_terms_of_service" value="<?php echo esc_attr(get_option('dgate_terms_of_service')); ?>" />
            </div>
        </div>

        <div class="grid-x grid-margin-x">
            <h2 class="cell medium-6">Privacy Policy</h2>
            <div class="cell medium-6">
                <input id="dgate_privacy_policy" type="text" name="dgate_privacy_policy" value="<?php echo esc_attr(get_option('dgate_privacy_policy')); ?>" />
            </div>
        </div>

        <div class="grid-x grid-margin-x">
            <h2 class="cell medium-6">Regret Text</h2>
            <div class="cell medium-6">
                <input id="dgate_regret_text" type="text" name="dgate_regret_text" value="<?php echo esc_attr(get_option('dgate_regret_text')); ?>" />
            </div>
        </div>

    <?php submit_button(); ?>
</section>