<?php 
$css = get_option('dgate_custom_css');
?>


<section class="cell medium-8 medium-offset-2">
    <h1><span class="fab fa-css3-alt" aria-hidden="true"></span> Custom CSS</h1>
    <div class="grid-x grid-margin-x">

        <!-- If Template is empty use a default template -->
        <div class="cell small-12" id="dgate_css_editor"><?php echo $css; ?></div>

    </div>
    <?php submit_button(); ?>
</section>