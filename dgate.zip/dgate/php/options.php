<?php
add_action('admin_menu', 'dgate_menu');

function dgate_menu()
{
    add_menu_page('dgate Settings', 'dgate', 'manage_options', 'dgate', 'dgate_options', plugins_url('/images/favicon.png', __FILE__));
    
    // call register settings function
    add_action('admin_init', 'register_dgate_settings');
    add_action('admin_init', 'register_dgate_editor_settings');
}

function register_dgate_settings()
{
    //register our settings
    register_setting('dgate_settings_group', 'dgate_brand_name');
    register_setting('dgate_settings_group', 'dgate_background');
    register_setting('dgate_settings_group', 'dgate_logo');
    register_setting('dgate_settings_group', 'dgate_heading');
    register_setting('dgate_settings_group', 'dgate_terms_of_service');
    register_setting('dgate_settings_group', 'dgate_privacy_policy');
    register_setting('dgate_settings_group', 'dgate_regret_text');
}

function register_dgate_editor_settings()
{
    //register our settings
    register_setting('dgate_settings_editor_group', 'dgate_custom_template');
    register_setting('dgate_settings_editor_group', 'dgate_custom_template_converted');
    register_setting('dgate_settings_editor_group', 'dgate_custom_css');
}


function dgate_options()
{
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    ?>
	<div class="grid-container">
        <img class="dgate-logo" src="<?php echo plugins_url('/images/logo.png', __FILE__); ?>">
        <h3 class="logo-subheading">Departika Age Gate</h3>
        <form method="post" action="options.php" class="grid-x grid-margin-y grid-padding-y grid-margin-x grid-padding-x">
            <?php settings_fields('dgate_settings_group'); ?>
            <?php do_settings_sections('dgate_settings_group'); ?>

            <!-- Configuration -->
            <?php include plugin_dir_path( __FILE__ ).'options/options_configuration.php'; ?>
        </form>


        <form id="editor-form" method="post" action="options.php" class="grid-x grid-margin-y grid-padding-y grid-margin-x grid-padding-x">
            <?php settings_fields('dgate_settings_editor_group'); ?>
            <?php do_settings_sections('dgate_settings_editor_group'); ?>

            <!-- JS Template Editor -->
            <?php include plugin_dir_path( __FILE__ ).'options/options_template.php'; ?>

            <!-- CSS Template Editor -->
            <?php include plugin_dir_path( __FILE__ ).'options/options_css.php'; ?>
        </form>
    </div>
<?php 
} ?>