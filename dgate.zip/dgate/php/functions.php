<?php 
// CUSTOM TEMPLATE
add_action("wp_ajax_update_template", "update_template");

function update_template() {
    $editor_data = trim($_POST['customTemplate']);

    update_option('dgate_custom_template', $editor_data);

    $config = array(
        'brand_name'       => get_option('dgate_brand_name'),
        'background'       => get_option('dgate_background'),
        'logo'             => get_option('dgate_logo'),
        'heading'          => get_option('dgate_heading'),
        'terms_of_service' => get_option('dgate_terms_of_service'),
        'privacy_policy"'  => get_option('dgate_privacy_policy'),
        'regret_text'      => get_option('dgate_regret_text'),
    );

    $tags = [
        '{{brand_name}}', 
        '{{background}}', 
        '{{logo}}', 
        '{{heading}}', 
        '{{terms_of_service}}', 
        '{{privacy_policy}}', 
        '{{regret_text}}'
    ];

    $tags_replace = [
        $config['brand_name'],
        $config['background'],
        $config['logo'],
        $config['heading'],
        $config['terms_of_service'],
        $config['privacy_policy'],
        $config['regret_text']
    ];

    $converted_data = str_replace($tags, $tags_replace, $editor_data);

    update_option('dgate_custom_template_converted', $converted_data);
    
    wp_die();
}


// CUSTOM CSS
add_action("wp_ajax_update_css", "update_css");

function update_css() {
    $editor_data = $_POST['customCSS'];

    update_option('dgate_custom_css', $editor_data);

    wp_die();
}